
package applibrary;


public class AppLibrary {

    
    public static void main(String[] args) {
        Publicacion p1,p2,p3;
        Ventas ventas=new Ventas();
        
        p1=new Publicacion("Cocina con amor",10000);
        p2=new Libro(600,2022,"Programar con java",20000);
        p3=new Disco(200,"Titulo amor",40000);
        
        p1.mostrar();
        p2.mostrar();
        p3.mostrar();
        
        ventas.addPublicacion(p2);
        ventas.addPublicacion(p3);
        
        System.out.println("Lista de publicaciones vendidas");
        
        ventas.mostrar();
    }
    
}
