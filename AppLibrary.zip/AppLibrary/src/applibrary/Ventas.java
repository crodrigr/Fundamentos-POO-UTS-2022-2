
package applibrary;

import java.util.ArrayList;


public class Ventas {
    
    public ArrayList<Publicacion> listVentas;
    
    public Ventas(){
       listVentas=new ArrayList<Publicacion>();
    }
    
    public void addPublicacion(Publicacion publicacion){
        listVentas.add(publicacion);
    }
    
    public void mostrar(){
        for(Publicacion p : this.listVentas  ){
            p.mostrar();
        }
    }
    
}
